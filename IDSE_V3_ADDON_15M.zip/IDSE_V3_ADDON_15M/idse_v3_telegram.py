#!/usr/bin/env python3
"""Additive Telegram adapter for the UNMODIFIED IDSE mobile monitor v3.

Reuses original v3 data collection and make_mobile Rich renderer. This is not
IDSE Statistics v4 and intentionally does not collect Docker, previews, etc.
Usage:
    python3 idse_v3_telegram.py --preview
    python3 idse_v3_telegram.py --send
"""
from __future__ import annotations

import argparse
import fcntl
import json
import os
import re
import stat
import subprocess
import sys
from datetime import datetime, timedelta
from io import StringIO
from pathlib import Path
from unittest.mock import patch

from rich.console import Console

import idse_openclaw_mobile_monitor_v3 as v3

HOME = Path.home()
DEFAULT_TARGET = '8830342871'  # Existing Telegram operator chat, not a bot token.
SECRET = HOME / '.config/idse-statistics/9router-dashboard-password'
LOCKFILE = HOME / '.cache/idse-v3-telegram.lock'
MAX_BODY_LENGTH = 3450  # Conservative for Telegram formatting.


def load_quota(reader):
    """Use the ORIGINAL v3 login method, with previously saved secret if safe."""
    try:
        st = SECRET.stat()
        if not stat.S_ISREG(st.st_mode) or st.st_uid != os.geteuid() or stat.S_IMODE(st.st_mode) != 0o600:
            return 'Secret dashboard tidak aman (owner/mode harus reaagent/600)'
        password = SECRET.read_text(encoding='utf-8').rstrip('\r\n')
        if not password:
            return 'Password dashboard kosong'
        # v3 login() calls getpass.getpass(); inject value without rewriting auth.
        with patch.object(v3.getpass, 'getpass', return_value=password):
            ok = reader.login()
        del password
        return '' if ok else 'Autentikasi dashboard gagal: ' + v3.tiny(reader.error, 50)
    except FileNotFoundError:
        return 'Secret dashboard belum tersedia; kuota bersifat opsional pada v3'
    except (OSError, UnicodeError) as exc:
        return 'Secret dashboard tidak bisa dibaca: ' + type(exc).__name__


def collect_snapshot():
    """A minimal extraction of the ORIGINAL main().poll() logic.

    All parsing, state interpretation, quota processing and rendering are
    delegated to the original untouched v3 functions.
    """
    config = v3.load_config()
    rows, sessions_error = v3.session_rows()
    if sessions_error and not rows:
        raise RuntimeError('Sumber sesi OpenClaw gagal dibaca: ' + v3.tiny(sessions_error, 90))
    sessions = v3.latest_sessions(rows)
    keys = [(sessions.get(a, {}).get('key') or sessions.get(a, {}).get('sessionKey')
             or v3.fallback_sessions(a)) for a in v3.AGENTS]
    tails = v3.get_tails(keys)

    reader = v3.QuotaReader('http://127.0.0.1:20128')
    quota_auth_note = load_quota(reader)
    reader.poll()
    quota = reader.by_provider()

    root = HOME / 'idse-ai-workspaces'
    state = v3.parse_state(root / 'idse-master/IDSE_AUTONOMOUS_STATE.json')
    completed = v3.read_completed(root, state)
    cron_run, cron_error = v3.last_cron_run(v3.DEFAULT_JOB)
    assignments = v3.tasks_from_cron(cron_run.get('summary', '') if cron_run else '')
    agents = v3.build_agents(config, rows, tails, state, assignments, quota)

    dispatch_time = v3.norm_epoch(cron_run.get('runAtMs')) if cron_run else None
    if dispatch_time:
        for aid in assignments:
            a = agents.get(aid)
            if a and a['status'] in ('IDLE', 'UNKNOWN'):
                key = a['session']
                last_evt = tails.get(key, {}).get('end') or v3.ms_last_run(sessions.get(aid, {}))
                if not last_evt or last_evt + timedelta(seconds=5) < dispatch_time:
                    a['status'] = 'WAITING'

    pool_path = HOME / '.openclaw/idse-model-pool/verified_pool.json'
    try:
        verified_count = len(json.loads(pool_path.read_text()).get('verified_refs', []))
    except (OSError, ValueError, AttributeError):
        verified_count = '?'

    # v3 mask_key exposes up to 10 chars: adapter shows NO credential chars.
    content = v3.make_mobile(
        agents, quota, sessions_error, cron_run, cron_error, state,
        completed, '[DISAMARKAN]', verified_count, 20, 54,
    )
    stream = StringIO()
    console = Console(file=stream, width=54, force_terminal=False,
                      color_system=None, highlight=False, soft_wrap=False)
    console.print(content)
    text = re.sub(r'refresh\s*\n\s*20s', 'update 15m', v3.clean(stream.getvalue()).strip())
    text = text.replace('refresh 20s', 'update 15m')
    if not text or 'AGENT' not in text or '9ROUTER' not in text:
        raise RuntimeError('Hasil renderer v3 kosong / tidak valid')

    warnings = []
    if quota_auth_note:
        warnings.append(quota_auth_note)
    elif reader.error:
        warnings.append('Quota 9Router: ' + v3.tiny(reader.error, 90))
    if reader.connection_map and len(reader.connection_map) > 8:
        warnings.append('Kuota v3 dibaca untuk maks. 8 dari '
                        + str(len(reader.connection_map)) + ' koneksi (batas asli v3)')
    if sessions_error:
        warnings.append('OpenClaw sessions: ' + v3.tiny(sessions_error, 90))

    return text, warnings


def telegram_messages(snapshot, warnings):
    # Code fences make the original Rich columns align in Telegram, rather than
    # pretending native Telegram table blocks exist.
    title = '📊 IDSE • MONITOR V3 ASLI\n' + datetime.now(v3.WIB).strftime('%d %b %Y %H:%M WIB')
    foot = ('\nSumber: OpenClaw + 9Router · snapshot setiap 15 menit'
            '\nStatus sesi adalah interpretasi monitor v3, bukan probe heartbeat.')
    if warnings:
        foot += '\n⚠️ ' + ' | '.join(v3.clean(w) for w in warnings)
    # Split only at real line boundaries. No data silently omitted.
    header_size = len(title) + len(foot) + 18
    budget = max(300, min(2800, MAX_BODY_LENGTH - header_size))
    lines = snapshot.splitlines()
    chunks = []
    curr = ''
    for line in lines:
        if len(line) > budget:
            raise RuntimeError('Baris render terlalu panjang untuk Telegram')
        if len(curr) + len(line) + 1 > budget and curr:
            chunks.append(curr.rstrip('\n'))
            curr = ''
        curr += line + '\n'
    if curr:
        chunks.append(curr.rstrip('\n'))
    msgs = []
    for i, body in enumerate(chunks):
        # Markdown literal backticks inside diagnostic text can prematurely close
        # code fences; replace those with safe apostrophes for display only.
        safe_body = body.replace('```', "'''")
        msg = (title + (f' · {i+1}/{len(chunks)}' if len(chunks) > 1 else '')
               + '\n```\n' + safe_body + '\n```')
        if i == len(chunks) - 1:
            msg += foot
        if len(msg) > MAX_BODY_LENGTH:
            raise RuntimeError('Pesan Telegram melebihi batas aman')
        msgs.append(msg)
    return msgs


def send_messages(messages, target):
    ids = []
    for i, msg in enumerate(messages, 1):
        try:
            result = subprocess.run(
                ['/usr/bin/openclaw', 'message', 'send', '--channel', 'telegram',
                 '--target', target, '--message', msg],
                capture_output=True, text=True, timeout=90, check=False,
            )
        except (OSError, subprocess.TimeoutExpired) as exc:
            print(f'ERROR send {i}/{len(messages)}: {type(exc).__name__}', file=sys.stderr)
            return False
        if result.returncode != 0:
            print(f'ERROR send {i}/{len(messages)}: exit={result.returncode}', file=sys.stderr)
            return False
        match = re.search(r'(?i)message\s*id\s*:\s*(\d+)', result.stdout + '\n' + result.stderr)
        if not match:
            print(f'UNVERIFIED send {i}/{len(messages)}: Message ID tidak ditemukan', file=sys.stderr)
            return False
        ids.append(match.group(1))
    print('OPENCLAW_SEND_OK message_ids=' + ','.join(ids) + ' target=' + target)
    return True


def main():
    parser = argparse.ArgumentParser(description='Add-on 15 menit untuk IDSE Mobile Monitor v3 asli')
    mode = parser.add_mutually_exclusive_group(required=True)
    mode.add_argument('--preview', action='store_true', help='Render saja; tidak mengirim Telegram')
    mode.add_argument('--send', action='store_true', help='Kirim snapshot ke bot OpenClaw')
    parser.add_argument('--target', default=DEFAULT_TARGET)
    args = parser.parse_args()
    if not re.fullmatch(r'\d{5,20}', args.target):
        parser.error('Telegram target ID harus numerik')
    if args.preview:
        try:
            snapshot, warnings = collect_snapshot()
            for msg in telegram_messages(snapshot, warnings):
                print(msg)
            return 0
        except Exception as exc:
            print('STOP snapshot v3: ' + v3.clean(str(exc))[:170], file=sys.stderr)
            return 1

    LOCKFILE.parent.mkdir(mode=0o700, parents=True, exist_ok=True)
    with LOCKFILE.open('a+') as lock:
        try:
            fcntl.flock(lock.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
        except BlockingIOError:
            print('SKIPPED: pengiriman sebelumnya masih berlangsung')
            return 0
        try:
            snapshot, warnings = collect_snapshot()
            messages = telegram_messages(snapshot, warnings)
        except Exception as exc:
            print('STOP snapshot v3: ' + v3.clean(str(exc))[:170], file=sys.stderr)
            return 1
        return 0 if send_messages(messages, args.target) else 1


if __name__ == '__main__':
    raise SystemExit(main())
