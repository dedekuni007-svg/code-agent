#!/usr/bin/env bash
# IDSE — install a deterministic 30-minute statistics scheduler for the existing
# idse_stats_direct.py. Does NOT touch 9Router, credentials, workers, or PM cron.
set -Eeuo pipefail
umask 077
TARGET_USER=reaagent
HOME_DIR=/home/reaagent
SCRIPT="$HOME_DIR/idse_stats_direct.py"
SECRET="$HOME_DIR/.config/idse-statistics/9router-dashboard-password"
TIMER=idse-statistik-30m.timer
SERVICE=idse-statistik-30m.service
PREFIX='[IDSE-30M]'

if [[ $EUID -ne 0 ]]; then
  echo "$PREFIX STOP: Jalankan sebagai root dengan sudo bash ..."; exit 1
fi
for cmd in python3 systemctl systemd-analyze runuser; do
  command -v "$cmd" >/dev/null || { echo "$PREFIX STOP: $cmd tidak tersedia"; exit 1; }
done
id "$TARGET_USER" >/dev/null
[[ -f "$SCRIPT" && -s "$SCRIPT" ]] || { echo "$PREFIX STOP: Script statistik tidak ditemukan: $SCRIPT"; exit 1; }
[[ -f "$SECRET" && -s "$SECRET" ]] || { echo "$PREFIX STOP: Password tersimpan tidak ditemukan: $SECRET"; exit 1; }
[[ ! -L "$SECRET" ]] || { echo "$PREFIX STOP: Secret berupa symlink"; exit 1; }
[[ "$(stat -c %a "$SECRET")" == '600' ]] || { echo "$PREFIX STOP: Permission secret bukan 600"; exit 1; }
[[ "$(stat -c %U "$SECRET")" == "$TARGET_USER" ]] || { echo "$PREFIX STOP: Secret bukan milik $TARGET_USER"; exit 1; }
python3 -m py_compile "$SCRIPT"

OC_PATH=$(runuser -l "$TARGET_USER" -c 'command -v openclaw' | tail -1)
[[ -n "$OC_PATH" && -x "$OC_PATH" ]] || { echo "$PREFIX STOP: OpenClaw CLI tidak ditemukan dalam akun $TARGET_USER"; exit 1; }
OC_DIR=$(dirname "$OC_PATH")
export OC_PATH

echo "$PREFIX Mengaudit cron OpenClaw agar tidak ada jadwal statistik duplikat..."
TEMP_JSON=$(mktemp)
trap 'rm -f "$TEMP_JSON"' EXIT
if ! runuser -l "$TARGET_USER" -c 'openclaw cron list --json' >"$TEMP_JSON" 2>/dev/null; then
  echo "$PREFIX STOP: Gagal membaca OpenClaw cron list; tidak memasang scheduler kedua."; exit 1
fi
OLD_IDS=$(python3 - "$TEMP_JSON" <<'PY'
import json, sys
from pathlib import Path
raw=Path(sys.argv[1]).read_text()
try: data=json.loads(raw)
except ValueError:
    # Handle occasional terminal banners before JSON, but never guess job IDs.
    try: data=json.loads(raw[raw.index('{'):])
    except Exception: raise SystemExit('STOP: Cron JSON tidak dapat dibaca')
if isinstance(data,list): jobs=data
elif isinstance(data,dict):
    jobs=data.get('jobs', data.get('items', data.get('data',{}).get('jobs',[]) if isinstance(data.get('data'),dict) else []))
else: jobs=[]
if not isinstance(jobs,list): raise SystemExit('STOP: Bentuk daftar cron tidak dikenali')
for job in jobs:
    if not isinstance(job,dict):continue
    name=str(job.get('name',job.get('title','')))
    # Disable ONLY the old periodic statistics job; not the PM controller.
    if name in ('auto-statistik-10m','auto-statistik-30m','IDSE Statistics 10m'):
        jid=job.get('id') or job.get('jobId')
        if not jid: raise SystemExit('STOP: Cron lama tanpa ID')
        print(jid)
PY
) || { echo "$PREFIX STOP: Tidak bisa memeriksa cron."; exit 1; }

systemd-analyze calendar '*-*-* *:00,30:00 Asia/Jakarta' >/dev/null

UNIT_PATH="/etc/systemd/system/$SERVICE"
TIMER_PATH="/etc/systemd/system/$TIMER"
BACKUP_PATH="/root/idse-statistik-service-backup-$(date +%Y%m%d-%H%M%S)"
mkdir -p "$BACKUP_PATH"; chmod 700 "$BACKUP_PATH"
for p in "$UNIT_PATH" "$TIMER_PATH"; do
  if [[ -f "$p" ]]; then cp -p "$p" "$BACKUP_PATH/$(basename "$p")"; fi
done

cat >"$UNIT_PATH" <<EOF
[Unit]
Description=IDSE Real 9Router Statistics -> Telegram (no AI model)
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
User=$TARGET_USER
Group=$TARGET_USER
WorkingDirectory=$HOME_DIR
Environment=HOME=$HOME_DIR
Environment=PATH=$OC_DIR:/usr/local/bin:/usr/bin:/bin
UMask=0077
ExecStart=/usr/bin/python3 $SCRIPT --send
TimeoutStartSec=15min
NoNewPrivileges=true
EOF

cat >"$TIMER_PATH" <<EOF
[Unit]
Description=IDSE Statistics every :00 and :30 WIB
[Timer]
OnCalendar=*-*-* *:00,30:00 Asia/Jakarta
Persistent=false
AccuracySec=5s
Unit=$SERVICE
[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
systemctl enable --now "$TIMER"
if ! systemctl is-active --quiet "$TIMER"; then
  echo "$PREFIX ERROR: Timer tidak aktif; cron lama tidak diubah."; exit 1
fi

if [[ -n "$OLD_IDS" ]]; then
  while IFS= read -r jid; do
    [[ -n "$jid" ]] || continue
    echo "$PREFIX Menonaktifkan HANYA job statistik lama ID: $jid"
    if ! runuser -l "$TARGET_USER" -c "openclaw cron disable '$jid'"; then
      echo "$PREFIX ERROR: Gagal menonaktifkan cron lama. Mematikan timer baru untuk mencegah duplikasi."
      systemctl disable --now "$TIMER" || true
      exit 1
    fi
  done <<<"$OLD_IDS"
fi

echo
echo '=== INSTALASI BERHASIL: SCHEDULER TANPA LLM ==='
systemctl list-timers "$TIMER" --no-pager --all
printf '\nUntuk mengirim SEKARANG: sudo systemctl start %s\n' "$SERVICE"
printf 'Untuk memeriksa hasil: sudo journalctl -u %s -n 35 --no-pager\n' "$SERVICE"
printf 'Cron PM/OpenClaw Controller: TIDAK DIUBAH\n'
printf 'Password dan 9Router: TIDAK DIUBAH\n'
printf 'Lingkup laporan: F1-F3 (kuota/usage), bukan A-E atau tombol Refresh\n'
