# IDSE Mobile Monitor v3 Asli — Add-on Telegram 15 Menit

**File sumber v3 asli dan `.sh` asli disalin tanpa mengubah 1 byte pun.**

| File | Peran |
|---|---|
| `idse_openclaw_mobile_monitor_v3.py` | Python v3 asli, 708 baris; pembacaan session/cron/state/kuota dan render terminal Rich tetap utuh |
| `IDSE_STATISTIK_30MIN_INSTALL.sh` | Installer asli 30 menit disimpan sebagai referensi **dan tidak dijalankan** |
| `idse_v3_telegram.py` | Add-on: menggunakan fungsi-fungsi v3, membuat snapshot dari hasil Rich, lalu mengirim melalui OpenClaw CLI |
| `INSTALL_V3_15M.sh` | Installer turunan: tes kirim sekali, lalu systemd timer di menit 00, 15, 30, 45 WIB |

**Lingkup laporan tetap sama seperti v3 asli:** status 7 agent, controller, status proyek, model, tugas, ringkasan kuota, pekerjaan selesai, dua event state. **Tidak** menambahkan Docker, live preview, ledger A–F, ataupun mekanisme `/stat`.

**Batasan asli v3:** pembacaan usage maksimal delapan koneksi pertama per polling; kuota opsional membutuhkan password dashboard yang sudah tersimpan dengan hak akses aman. Bila kuota gagal, tampilkan status tidak tersedia; jangan mengarang angka. Status RUNNING/ERROR berasal dari interpretasi jejak session dan dapat mencerminkan kejadian historis.

## Instalasi dari Termius Android (root)

1. Upload `IDSE_V3_ADDON_15M.zip` via SFTP Termius ke `/home/reaagent/IDSE_V3_ADDON_15M.zip`.
2. Paste **satu baris** ini ke terminal (tidak memakai `set -e` pada shell aktif):

```bash
cd /home/reaagent && unzip -oq IDSE_V3_ADDON_15M.zip && bash /home/reaagent/IDSE_V3_ADDON_15M/INSTALL_V3_15M.sh
```

**Bagaimana bukti dikumpulkan:** installer memanggil add-on sebagai user `reaagent`; add-on membaca sumber menggunakan v3 asli, memanggil `openclaw message send --channel telegram --target 8830342871`, dan **hanya** menerima tes kirim sebagai sukses jika CLI mengembalikan Message ID. Anda tetap perlu melihat pesan di KAI DEV Telegram untuk verifikasi tampilan. Timer baru diaktifkan setelah tes itu sukses. Jika tes gagal, timer sebelumnya tidak berubah.

Timer lama `idse-stat-15m.timer` dan `idse-statistik-30m.timer` akan dimatikan hanya setelah tes kirim baru lulus, untuk mencegah duplikat. Tidak mengubah Gateway, plugin, PM cron, dispatch, 9Router, atau file Python v4.

## Perintah pemeriksaan dan kendali

```bash
# Pratinjau (tanpa pengiriman Telegram):
runuser -l reaagent -c '/usr/bin/python3 /home/reaagent/idse-v3-monitor/idse_v3_telegram.py --preview'

# Tes kirim ulang (muncul Message ID di terminal bila berhasil):
runuser -l reaagent -c '/usr/bin/python3 /home/reaagent/idse-v3-monitor/idse_v3_telegram.py --send'

# Jadwal otomatis:
systemctl list-timers idse-v3-15m.timer --all --no-pager

# Log:
journalctl -u idse-v3-15m.service -n 30 --no-pager

# Berhenti mengirim otomatis:
systemctl disable --now idse-v3-15m.timer
```

`--preview` adalah bentuk tekstual tabel terminal `rich` v3 dengan pembatas kode agar kolom sejajar. Ini **bukan** Telegram Native Rich Table.

## Tidak perlu menginstal bot Telegram baru

Target sudah menggunakan bot OpenClaw yang ada dan operator chat `8830342871`. Tidak memerlukan token bot baru, callback, atau plugin slash command.
