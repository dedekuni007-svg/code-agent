#!/usr/bin/env bash
# Derivative installer based on the user's unmodified IDSE_STATISTIK_30MIN_INSTALL.sh.
# Differences: keep v3 monitor untouched, use its Telegram adapter, 15-minute timer,
# immediate send test, then replace only known previous *statistics* timers.
# Run with: bash /home/reaagent/IDSE_V3_ADDON_15M/INSTALL_V3_15M.sh
# Never source this file into an interactive Termius shell.
set -Eeuo pipefail
umask 077
PREFIX='[IDSE-V3-15M]'
USER_NAME=reaagent
HOME_DIR=/home/reaagent
SRC_DIR="$HOME_DIR/IDSE_V3_ADDON_15M"
APP_DIR="$HOME_DIR/idse-v3-monitor"
V3="${APP_DIR}/idse_openclaw_mobile_monitor_v3.py"
SEND="${APP_DIR}/idse_v3_telegram.py"
TIMER=idse-v3-15m.timer
SERVICE=idse-v3-15m.service
KNOWN_OLD_TIMERS=(idse-stat-15m.timer idse-statistik-30m.timer)

if [[ $EUID -ne 0 ]]; then
  echo "$PREFIX STOP: Jalankan melalui shell root Termius: bash INSTALL_V3_15M.sh"
  exit 1
fi
for cmd in install sha256sum python3 runuser systemctl systemd-analyze id grep; do
  command -v "$cmd" >/dev/null || { echo "$PREFIX STOP: $cmd tidak tersedia"; exit 1; }
done
id "$USER_NAME" >/dev/null || { echo "$PREFIX STOP: user $USER_NAME tidak tersedia"; exit 1; }
[[ -s "$SRC_DIR/idse_openclaw_mobile_monitor_v3.py" && -s "$SRC_DIR/idse_v3_telegram.py" ]] || {
  echo "$PREFIX STOP: File Python asli + adapter belum diekstrak ke $SRC_DIR"; exit 1;
}

# Reference hash to guarantee original uploaded v3 is not silently replaced.
V3_SHA='2c6f92bea7888e9d35c1783fcc5e9d4cdedaee20a6f51f1c3d98ca26560a09e8'
SH_SHA='a33e5cea3646de2ae961ce244a1839d1d4637814ba45a4caf7bdddb43d53d0ad'
printf '%s  %s\n' "$V3_SHA" "$SRC_DIR/idse_openclaw_mobile_monitor_v3.py" | sha256sum -c - >/dev/null || {
  echo "$PREFIX STOP: Isi Python v3 berbeda dari file asli yang dikirim"; exit 1;
}
printf '%s  %s\n' "$SH_SHA" "$SRC_DIR/IDSE_STATISTIK_30MIN_INSTALL.sh" | sha256sum -c - >/dev/null || {
  echo "$PREFIX STOP: Isi installer 30 menit berbeda dari file asli yang dikirim"; exit 1;
}

install -d -o "$USER_NAME" -g "$USER_NAME" -m 750 "$APP_DIR"
install -o "$USER_NAME" -g "$USER_NAME" -m 644 "$SRC_DIR/idse_openclaw_mobile_monitor_v3.py" "$V3"
install -o "$USER_NAME" -g "$USER_NAME" -m 700 "$SRC_DIR/idse_v3_telegram.py" "$SEND"
install -o "$USER_NAME" -g "$USER_NAME" -m 600 "$SRC_DIR/IDSE_STATISTIK_30MIN_INSTALL.sh" "$APP_DIR/IDSE_STATISTIK_30MIN_INSTALL.original.sh"

runuser -l "$USER_NAME" -c '/usr/bin/python3 -c "import rich"' || {
  echo "$PREFIX STOP: Library Rich belum tersedia untuk reaagent; timer tidak diubah"; exit 1;
}
runuser -l "$USER_NAME" -c '/usr/bin/python3 -m py_compile /home/reaagent/idse-v3-monitor/idse_openclaw_mobile_monitor_v3.py /home/reaagent/idse-v3-monitor/idse_v3_telegram.py' || {
  echo "$PREFIX STOP: Syntax error; timer tidak diubah"; exit 1;
}
[[ -x /usr/bin/openclaw ]] || { echo "$PREFIX STOP: /usr/bin/openclaw tidak ditemukan"; exit 1; }

# DO NOT schedule until the exact same read+render+send path succeeds once.
echo "$PREFIX TEST OPENCLAW TELEGRAM SEND SEKARANG ..."
if ! runuser -l "$USER_NAME" -c '/usr/bin/python3 /home/reaagent/idse-v3-monitor/idse_v3_telegram.py --send'; then
  echo "$PREFIX STOP: Pengiriman belum sukses; timer lama tidak diubah, timer baru tidak diaktifkan"
  exit 1
fi

echo "$PREFIX Test selesai: nomor Message ID diberikan oleh OpenClaw CLI."
systemd-analyze calendar '*-*-* *:00,15,30,45:00 Asia/Jakarta' >/dev/null || {
  echo "$PREFIX STOP: Jadwal Asia/Jakarta tidak valid"; exit 1;
}

UNIT_PATH="/etc/systemd/system/$SERVICE"
TIMER_PATH="/etc/systemd/system/$TIMER"
BACKUP_DIR="/root/idse-v3-15m-unit-backup-$(date +%Y%m%d-%H%M%S)"
install -d -m 700 "$BACKUP_DIR"
for item in "$UNIT_PATH" "$TIMER_PATH"; do
  [[ -f "$item" ]] && cp -p "$item" "$BACKUP_DIR/" || true
done
UID_NUM=$(id -u "$USER_NAME")
cat >"$UNIT_PATH" <<EOF
[Unit]
Description=IDSE Original v3 Monitor -> OpenClaw Telegram (no LLM)
After=network-online.target
Wants=network-online.target
[Service]
Type=oneshot
User=$USER_NAME
Group=$USER_NAME
WorkingDirectory=$APP_DIR
Environment=HOME=$HOME_DIR
Environment=PATH=/usr/local/bin:/usr/bin:/bin
Environment=XDG_RUNTIME_DIR=/run/user/$UID_NUM
UMask=0077
ExecStart=/usr/bin/python3 $SEND --send
TimeoutStartSec=12min
NoNewPrivileges=true
EOF
cat >"$TIMER_PATH" <<EOF
[Unit]
Description=IDSE original v3 Telegram monitor every 15 minutes
[Timer]
OnCalendar=*-*-* *:00,15,30,45:00 Asia/Jakarta
Persistent=false
AccuracySec=10s
Unit=$SERVICE
[Install]
WantedBy=timers.target
EOF

systemctl daemon-reload
# Save/stop only known *statistics* timers to prevent duplicate messages.
OLD_ACTIVE=()
for name in "${KNOWN_OLD_TIMERS[@]}"; do
  if systemctl is-active --quiet "$name"; then
    OLD_ACTIVE+=("$name")
    systemctl disable --now "$name" || {
      echo "$PREFIX ERROR: Failed stopping $name; new timer not enabled"; exit 1;
    }
  fi
done

if ! systemctl enable --now "$TIMER" || ! systemctl is-active --quiet "$TIMER"; then
  echo "$PREFIX ERROR: Timer baru gagal. Mencoba mengaktifkan kembali timer lama."
  systemctl disable --now "$TIMER" || true
  for name in "${OLD_ACTIVE[@]}"; do systemctl enable --now "$name" || true; done
  exit 1
fi

echo
printf '%s\n' '=== INSTALL PASS: IDSE V3 ORIGINAL + TELEGRAM ADD-ON ==='
echo "$PREFIX Python v3 asli SHA256: $V3_SHA"
echo "$PREFIX Python v4 TIDAK DIGUNAKAN"
echo "$PREFIX /stat plugin dan Gateway TIDAK DIUBAH"
echo "$PREFIX Service worker, dispatcher, 9Router TIDAK DIUBAH"
systemctl list-timers "$TIMER" --all --no-pager
printf '\nTEST ULANG MANUAL (di Termius): systemctl start %s\n' "$SERVICE"
printf 'LOG: journalctl -u %s -n 30 --no-pager\n' "$SERVICE"
printf 'STOP OTOMATIS: systemctl disable --now %s\n' "$TIMER"
