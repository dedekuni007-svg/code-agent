#!/usr/bin/env python3
"""IDSE live terminal dashboard for OpenClaw 2026.10.x and local 9Router.

Read-only; never triggers an agent, cron run, inferencing or service restart.
Uses OpenClaw CLI session trajectory and cron history, and optionally 9Router
admin quota APIs. Requires pip install rich.
"""
from __future__ import annotations

import argparse
import concurrent.futures
import getpass
import http.cookiejar
import json
import os
import re
import shutil
import subprocess
import sys
import time
import urllib.error
import urllib.request
from collections import defaultdict, deque
from datetime import datetime, timedelta, timezone
from http.cookies import SimpleCookie
from pathlib import Path
from zoneinfo import ZoneInfo

from rich import box
from rich.console import Console, Group
from rich.live import Live
from rich.panel import Panel
from rich.table import Table
from rich.text import Text

VERSION = '3.0.0'
WIB = ZoneInfo('Asia/Jakarta')
UTC = timezone.utc
DEFAULT_JOB = 'e9572e34-b641-4034-9356-c26f78bfc9c7'
AGENTS = ['idse-master', 'idse-router', 'idse-market', 'idse-chat',
          'idse-builder', 'idse-deploy', 'idse-qa']
ROLE = {'idse-master':'MASTER', 'idse-router':'ROUTER', 'idse-market':'MARKET',
        'idse-chat':'CHAT', 'idse-builder':'BUILDER', 'idse-deploy':'DEPLOY',
        'idse-qa':'QA', 'main':'REA'}
TASK_FALLBACK = {
    'idse-master':'Koordinasi & pemeriksaan QA',
    'idse-router':'Audit router / 9Router / model pool',
    'idse-market':'Ledger, billing, PostgreSQL',
    'idse-chat':'AI Chat & Media (belum terkonfirmasi)',
    'idse-builder':'Orkestrasi builder & sandbox',
    'idse-deploy':'GitHub & deployment (belum terkonfirmasi)',
    'idse-qa':'Audit & integrasi',
    'main':'REA legacy'}
ESC_RE = re.compile(r'\x1b\[[0-?]*[ -/]*[@-~]')
EVENT_RE = re.compile(r'(?P<hms>\d{2}:\d{2}:\d{2})\s+(?P<event>session\.started|session\.ended|model\.completed|tool\.call|tool\.result|prompt\.submitted|context\.compiled)\s+.*')
MODEL_RE = re.compile(r'\b(?:9router/)?(?:ag|kr|cf|gemini|cbai|cx|nvidia|oc|mmf)/[^\s]+')
SECRET_RE = re.compile(r'(?i)(?:sk-[\w-]{8,}|Bearer\s+[\w.=-]{8,}|auth_token=[^\s;]+)')


def clean(s):
    s = ESC_RE.sub('', str(s or ''))
    return SECRET_RE.sub('[REDACTED]', s)


def jload(text):
    t = clean(text)
    for idx, c in enumerate(t):
        if c not in '{[':
            continue
        try:
            return json.JSONDecoder().raw_decode(t[idx:])[0]
        except ValueError:
            continue
    raise ValueError('Tidak ada JSON valid dari CLI')


def command(args, timeout=16):
    try:
        p = subprocess.run(args, capture_output=True, text=True, timeout=timeout,
                           cwd=str(Path.home()), stdin=subprocess.DEVNULL)
        if p.returncode:
            return None, f'CLI exit {p.returncode}: {clean(p.stderr)[-120:]}'
        return p.stdout, None
    except subprocess.TimeoutExpired:
        return None, 'CLI timeout'
    except (OSError, ValueError) as ex:
        return None, type(ex).__name__


def json_command(args, timeout=16):
    out, err = command(args, timeout)
    if err:
        return None, err
    try:
        return jload(out), None
    except ValueError:
        return None, 'CLI JSON tidak kompatibel'


def norm_epoch(val):
    if isinstance(val, (float, int)) and val > 0:
        if val > 1e12: val /= 1000
        if val < 1e10:
            try: return datetime.fromtimestamp(val, UTC)
            except (OSError, ValueError, OverflowError): return None
    if isinstance(val,str):
        try:
            d = datetime.fromisoformat(val.replace('Z','+00:00'))
            return d if d.tzinfo else d.replace(tzinfo=UTC)
        except ValueError: return None
    return None


def hh_wib(v):
    dt = norm_epoch(v) if not isinstance(v, datetime) else v
    return dt.astimezone(WIB).strftime('%H:%M:%S') if dt else '-'


def inferred_utc_time(hms):
    """Trajectory CLI shows UTC HH:MM:SS without date; choose recent day."""
    now = datetime.now(UTC)
    try: h,m,s = (int(x) for x in hms.split(':'))
    except Exception: return None
    t = now.replace(hour=h, minute=m, second=s, microsecond=0)
    if t > now + timedelta(minutes=4): t -= timedelta(days=1)
    return t


def ms_last_run(row):
    for k in ('updatedAt','lastActivityAt','lastRunAt','lastMessageAt','updated','timestamp','createdAt'):
        v = norm_epoch(row.get(k))
        if v: return v
    return None


def make_tail_info(txt):
    events=[]
    for line in clean(txt).splitlines():
        m=EVENT_RE.search(line)
        if m: events.append((inferred_utc_time(m.group('hms')), m.group('event'), line))
    started=None; ended=None; last_model=None; last_error=None
    last_event = events[-1] if events else None
    for d,ev,line in events:
        if ev=='session.started': started=d; ended=None; last_error=None
        if ev=='session.ended': ended=d; last_error=('error' in line or 'interrupted' in line or 'failed' in line)
        if ev=='model.completed':
            m=MODEL_RE.search(line)
            if m: last_model=m.group().strip()
            if ' timeout' in line or ' error' in line: last_error=True
    status='UNKNOWN'
    if started:
        if ended and ended >= started:
            status = 'ERROR' if last_error else 'IDLE'
        elif (datetime.now(UTC)-started).total_seconds() <= 900:
            status='RUNNING'
        else: status='STALE'
    elif last_event:
        status = 'IDLE' if last_event[1] in ('session.ended','model.completed') else 'UNKNOWN'
    return {'start': started, 'end': ended, 'status': status,
            'last_event': last_event[1] if last_event else '-', 'model': last_model}


def model_prefix(model):
    p=str(model or '').split('/')
    return p[1] if len(p)>=3 and p[0]=='9router' else (p[0] if len(p)>1 else '-')


def model_short(model, width=24):
    m=str(model or '-').removeprefix('9router/')
    if len(m)<=width: return m
    return m[:max(2,width-1)] + '…'


def mask_key(key):
    if isinstance(key,str) and key:
        if key.startswith('${') or key.startswith('secret:') or key.startswith('env:'):
            return 'SECRET_REF (tidak ditampilkan)'
        if key.lower().startswith(('sk-','key-','idse-')):
            return key[:10] + '**********' if len(key)>10 else '**********'
    return 'N/A (credential tidak tersedia sebagai teks)'


def parse_state(path):
    """Read persistent milestone state, never confuse historic PASS with execution."""
    result={'tasks':{}, 'done':[], 'gates':{}, 'history':[],
            'top_status':'UNKNOWN', 'current_note':'', 'updated':'-'}
    try:
        d=json.loads(path.read_text())
        result['updated']=datetime.fromtimestamp(path.stat().st_mtime, WIB).strftime('%d/%m %H:%M')
    except (OSError,ValueError): return result
    if not isinstance(d,dict):return result
    result['top_status']=str(d.get('status') or d.get('overallStatus') or d.get('projectStatus') or 'UNKNOWN').upper()
    current=[]
    for key in ('currentPhase','phase','current_phase','nextAction','next_action','awaiting','waitingFor','waiting_for',
                'approvalStatus','ownerApproval','requiresApproval','needsApproval','pendingApproval','approval',
                'blockedReason','blocker','statusReason','decision'):
        value=d.get(key)
        if isinstance(value,dict):
            value=value.get('status') or value.get('state') or value.get('reason') or value.get('required')
        if isinstance(value,(str,bool)) and str(value).strip(): current.append(f'{key}={value}')
    result['current_note']=' | '.join(current)[:500]
    for key in ('gates','modules','workers','agents','tasks'):
        container=d.get(key)
        if not isinstance(container,dict): continue
        for name,value in container.items():
            label=str(name).lower().replace('_','-')
            agent=next((a for a in AGENTS if a in label or label in (a,a.removeprefix('idse-'))), None)
            if isinstance(value,dict):
                status=str(value.get('status') or value.get('state') or '').upper()
                desc=str(value.get('task') or value.get('description') or value.get('title') or name)[:180]
            elif isinstance(value,str):
                status=value.upper();desc=str(name)[:180]
            else:continue
            if agent:
                if desc.lower() not in (agent,agent.removeprefix('idse-')):
                    result['tasks'][agent]=clean(desc)
                result['gates'][agent]=status
            if status in ('DONE','VERIFIED','FINAL_PASS','PASS','COMPLETED','VERIFIED_PASS'):
                result['done'].append((str(name)[:26],desc,'state claim'))
    history=d.get('history') or d.get('events') or []
    if isinstance(history,list):
        for event in history[-12:]:
            if not isinstance(event,dict): continue
            label=event.get('event') or event.get('type') or ''
            note=event.get('note') or event.get('message') or ''
            time_label=str(event.get('ts') or event.get('timestamp') or '')
            if label:result['history'].append((time_label,clean(label),tiny(note,95)))
    return result


def approval_signal(state, cron):
    """Only infer pending approval when the *current* report says so."""
    # Recent cron is preferred: historical QA notes do not imply current approval.
    summary=str(cron.get('summary') or '') if isinstance(cron,dict) else ''
    sources=[summary, str(state.get('current_note') or '')]
    for src in sources:
        low=src.lower()
        if re.search(r'(?:awaiting|waiting for|pending|needs?|requires?|menunggu|perlu|butuh).{0,65}(?:owner.{0,12}approv|persetujuan|approval)', low) or \
           re.search(r'(?:owner.{0,10}approval|persetujuan owner).{0,42}(?:required|pending|needed|menunggu)',low):
            return 'NEED APPROVAL','Owner diperlukan untuk tahap berikutnya (berdasarkan laporan terbaru)'
    if isinstance(cron,dict) and str(cron.get('completionStatus') or cron.get('status') or '').lower() in ('failed','error','timed_out'):
        return 'CONTROLLER ERROR','Jadwal terakhir gagal; lihat cron runs'
    gate_status=str(state.get('top_status') or 'UNKNOWN').upper()
    if gate_status in ('BLOCKED','FAILED','ERROR'):return 'BLOCKED','State proyek mencatat blocker'
    if any(x in gate_status for x in ('PENDING_APPROVAL','NEED_APPROVAL','AWAITING_APPROVAL')):
        return 'NEED APPROVAL','State proyek meminta persetujuan Owner'
    if isinstance(cron,dict) and re.search(r'(no active tasks|no tasks to dispatch|tidak ada tugas aktif)',summary,re.I):
        return 'NO ACTIVE TASK','Controller melaporkan belum ada pekerjaan baru'
    if gate_status in ('FINAL_PASS','VERIFIED_PASS'):
        return 'PHASE PASS','State mengklaim PASS; pastikan cakupan QA sebelum deploy'
    return 'UNCONFIRMED','Belum ada bukti eksplisit RUNNING / NEED APPROVAL dari state'


def read_completed(workspace_root, state, max_entries=16):
    """List explicit completion evidence; exclude narrative bullet marketing."""
    found=[]
    for agent in AGENTS:
        root=workspace_root/agent
        for filename in ('ROUTER_PROGRESS.md','MARKET_PROGRESS.md','BUILDER_PROGRESS.md',
                         'QA_PHASE5_REPORT.md', 'QA_FINAL_REPORT.md'):
            p=root/filename
            if not p.is_file():continue
            try:lines=p.read_text(errors='replace')[:160_000].splitlines()
            except OSError:continue
            for line in lines:
                line=line.strip()
                if re.match(r'^[-*]\s*\[[xX]\]\s+\S',line):
                    found.append((ROLE.get(agent,agent),re.sub(r'^[-*]\s*\[[xX]\]\s*','',line)[:105],p.name))
            break
    # Explicit state events are displayed as *claims*, not independent QA.
    for ts,event,note in state.get('history',[]):
        if re.search(r'(?:PASS|DONE|COMPLETE|CLEARED|FIXED|APPROVED)',event,re.I):
            found.append(('STATE',tiny(event+((' — '+note) if note else ''),110),'state event'))
    found.extend(state.get('done',[]))
    res=[];seen=set()
    for a,t,src in found:
        key=(a,t)
        if key not in seen and t:
            res.append((a,clean(t),src));seen.add(key)
    return res[-max_entries:]


def tasks_from_cron(summary):
    tasks={}
    for line in str(summary or '').splitlines():
        if not line.lstrip().startswith('|'): continue
        for a in AGENTS:
            if f'`{a}`' in line:
                cells = [c.strip().strip('`') for c in line.split('|') if c.strip()]
                if len(cells)>=4:
                    tasks[a]=clean(cells[-1])[:140]
    return tasks


class QuotaReader:
    """Dashboard auth cookie is kept only in RAM, and only sent to loopback."""
    def __init__(self, url):
        self.url=url.rstrip('/')
        from urllib.parse import urlsplit
        u=urlsplit(self.url)
        if u.hostname not in ('127.0.0.1','localhost','::1') or u.scheme!='http':
            raise ValueError('Quota login hanya diizinkan melalui loopback HTTP lokal')
        self.jar=http.cookiejar.CookieJar()
        self.opener=urllib.request.build_opener(urllib.request.HTTPCookieProcessor(self.jar),
                urllib.request.ProxyHandler({}))
        self.cookie=None
        self.connection_map=[];self.cache={};self.last_accounts=0;self.last_quota=0
        self.error='Belum login (gunakan --quota-login)'

    def request(self,path,body=None):
        h={'Accept':'application/json','User-Agent':'IDSE-Live-Rich/'+VERSION}
        if self.cookie: h['Cookie']='auth_token='+self.cookie
        if body is not None: h['Content-Type']='application/json'
        r=urllib.request.Request(self.url+path, method='POST' if body is not None else 'GET',
                                 headers=h, data=json.dumps(body).encode() if body is not None else None)
        try:
            with self.opener.open(r,timeout=5) as res:
                raw=res.read(2_000_001)
                if len(raw)>2_000_000: raise ValueError('Response too large')
                return json.loads(raw),res.headers
        except urllib.error.HTTPError as e: raise ValueError('HTTP_'+str(e.code)) from None
        except (OSError, TimeoutError, ValueError) as e: raise ValueError(type(e).__name__ if not isinstance(e,ValueError) else str(e)) from None

    def login(self):
        pw=getpass.getpass('9Router dashboard password (hidden, RAM only; Enter=skip): ')
        if not pw:return False
        try:
            d,h=self.request('/api/auth/login',{'password':pw})
            if not isinstance(d,dict) or d.get('success') is not True:
                raise ValueError('Login unsuccessful')
            for line in h.get_all('Set-Cookie',[]) or []:
                cookies=SimpleCookie();cookies.load(line)
                item=cookies.get('auth_token')
                if item and re.fullmatch(r'[\w.~-]{8,12000}',item.value):
                    self.cookie=item.value; break
            if not self.cookie:
                for item in self.jar:
                    if item.name=='auth_token': self.cookie=item.value
            if not self.cookie: raise ValueError('Auth cookie missing')
            status,_=self.request('/api/auth/status')
            if not isinstance(status,dict) or status.get('authenticated') is not True:
                raise ValueError('Dashboard session rejected')
            self.error='';return True
        except ValueError as e:
            self.error=str(e); self.cookie=None;return False

    @staticmethod
    def quota_windows(raw):
        if not isinstance(raw,dict):return []
        q=raw.get('quotas'); items=q.items() if isinstance(q,dict) else []
        if not items: items=[('general',raw)]
        res=[]
        for name,v in items:
            if not isinstance(v,dict):continue
            rem=v.get('remaining');tot=v.get('total') or v.get('limit');pct=v.get('remainingPercentage')
            if not isinstance(pct,(int,float)) and isinstance(rem,(int,float)) and isinstance(tot,(int,float)) and tot:
                pct=rem/tot*100
            if not isinstance(pct,(int,float)):
                used=v.get('usedPercentage')
                if isinstance(used,(int,float)):pct=100-used
            if isinstance(pct,(float,int)):
                res.append((str(name)[:24],max(0,min(100,round(pct))),v.get('resetAt')))
        return res

    def poll(self):
        if not self.cookie: return
        now=time.monotonic()
        if now-self.last_accounts>=120 or not self.connection_map:
            try:
                d,_=self.request('/api/providers')
                if not isinstance(d,dict) or not isinstance(d.get('connections'),list):raise ValueError('Invalid provider schema')
                self.connection_map=d['connections']; self.last_accounts=now;self.error=''
            except ValueError as e:self.error=str(e);return
        if now-self.last_quota<120:return
        # Cap endpoint calls to avoid flooding upstream quota refresh APIs.
        pending=[]
        for item in self.connection_map[:8]:
            if not isinstance(item,dict): continue
            uid=item.get('id')
            if isinstance(uid,str) and re.fullmatch(r'[\w-]{4,100}',uid):
                pending.append(uid)
        # Login cookie remains in RAM; cap concurrent upstream quota reads.
        with concurrent.futures.ThreadPoolExecutor(max_workers=3) as pool:
            future={pool.submit(self.request,'/api/usage/'+uid):uid for uid in pending}
            for task,uid in future.items():
                try:
                    raw,_=task.result()
                    self.cache[uid]=self.quota_windows(raw)
                except (ValueError,TimeoutError):
                    self.cache[uid]=[]
        self.last_quota=time.monotonic()

    def by_provider(self):
        alias={'antigravity':'ag','cloudflare':'cf','google-antigravity':'ag',
               'gemini-cli':'gemini','kiro':'kr','codebuddy-intl':'cbai',
               'nvidia-nim':'nvidia','opencode':'oc','google-gemini':'gemini'}
        output=defaultdict(lambda: {'accounts':0,'reporting':0,'lowest':None,'reset':None})
        for con in self.connection_map:
            if not isinstance(con,dict):continue
            raw=con.get('provider') or con.get('providerId') or con.get('type') or ''
            if isinstance(raw,dict):raw=raw.get('id') or ''
            key=alias.get(str(raw).lower(),str(raw).lower())
            a=output[key];a['accounts']+=1
            items=self.cache.get(con.get('id'),[])
            if items:
                a['reporting']+=1
                worst=min(items,key=lambda x:x[1])
                if a['lowest'] is None or worst[1]<a['lowest']:
                    a['lowest']=worst[1];a['reset']=worst[2]
        return dict(output)


def last_cron_run(job):
    d,e=json_command(['openclaw','cron','runs','--id',job,'--limit','3'],timeout=14)
    if e:return {},e
    if not isinstance(d,dict):return {},'Invalid cron response'
    entries=d.get('entries',[])
    return entries[0] if isinstance(entries,list) and entries else {},None


def read_router_key(config):
    provider=config.get('models',{}).get('providers',{}).get('9router',{})
    k=provider.get('apiKey') if isinstance(provider,dict) else None
    if isinstance(k,str) and k.startswith('${'):
        env=k.strip('${}')
        k=os.environ.get(env)
    return mask_key(k)


def session_rows():
    d,e=json_command(['openclaw','sessions','--all-agents','--limit','100','--json'],timeout=20)
    if e:return [],e
    rows=d if isinstance(d,list) else d.get('sessions',[]) if isinstance(d,dict) else []
    return [r for r in rows if isinstance(r,dict)],None


def fallback_sessions(agent):
    if agent=='idse-master':return 'agent:idse-master:idse-build-main'
    return f'agent:{agent}:main'


def latest_sessions(rows):
    out={}
    for r in rows:
        a=r.get('agentId')
        key=r.get('key') or r.get('sessionKey')
        if not a and isinstance(key,str) and key.startswith('agent:'):
            a=key.split(':',2)[1]
        if a not in AGENTS and a!='main':continue
        # updatedAt epoch may be absent in older builds; trust CLI list order then.
        if a not in out or (ms_last_run(r) or datetime.min.replace(tzinfo=UTC)) > (ms_last_run(out[a]) or datetime.min.replace(tzinfo=UTC)):
            out[a]=r
    return out


def get_tails(keys):
    out={}
    def one(k):
        stdout,err=command(['openclaw','sessions','tail','--session-key',k,'--tail','90'],timeout=13)
        return make_tail_info(stdout) if not err else {'status':'UNKNOWN','start':None,'end':None,'model':None,'last_event':'-'}
    if not keys:return out
    with concurrent.futures.ThreadPoolExecutor(max_workers=2) as pool:
        fut={pool.submit(one,k):k for k in keys}
        for f,k in fut.items():
            try:out[k]=f.result()
            except Exception:out[k]={'status':'UNKNOWN','start':None,'end':None,'model':None,'last_event':'-'}
    return out


def field_status(status):
    return {'RUNNING':'[bold green]RUNNING[/]', 'DONE':'[green]DONE[/]', 'IDLE':'[cyan]IDLE[/]',
            'WAITING':'[yellow]WAITING[/]', 'ERROR':'[bold red]ERROR[/]',
            'STALE':'[yellow]STALE[/]', 'UNKNOWN':'[dim]UNKNOWN[/]',
            'BLOCKED':'[red]BLOCKED[/]'}.get(status,'[dim]'+str(status)+'[/]')


def build_agents(config, rows, tails, state, assign, quota):
    entries=config.get('agents',{}).get('entries',{})
    sessions=latest_sessions(rows)
    result={}
    for aid in AGENTS:
        cfg=entries.get(aid,{}) if isinstance(entries,dict) else {}
        row=sessions.get(aid,{})
        key=row.get('key') or row.get('sessionKey') or fallback_sessions(aid)
        trace=tails.get(key,{})
        status=trace.get('status','UNKNOWN')
        gate=state.get('gates',{}).get(aid)
        if gate in ('BLOCKED','FAILED') and status!='RUNNING':status='BLOCKED'
        elif gate in ('WAITING_DEPENDENCY','WAITING','QUEUED','DISPATCHED') and status in ('IDLE','UNKNOWN'):status='WAITING'
        elif gate in ('PENDING_APPROVAL','NEED_APPROVAL','AWAITING_APPROVAL') and status!='RUNNING':status='NEED APPROVAL'
        task=state.get('tasks',{}).get(aid) or assign.get(aid) or 'Belum ada tugas aktif tercatat'
        model=trace.get('model') or row.get('model')
        if model and not str(model).startswith('9router/'):model='9router/'+str(model)
        config_only=not bool(model)
        if not model:
            mc=cfg.get('model',{});model=mc.get('primary') if isinstance(mc,dict) else mc
        start=trace.get('start');end=trace.get('end')
        if start and end and end >= start:
            duration=f'{int((end-start).total_seconds())}s'
        elif start and status=='RUNNING':duration=f'{int((datetime.now(UTC)-start).total_seconds())}s'
        else: duration='-'
        pref=model_prefix(model)
        q=quota.get(pref,{}); quota_display=(str(q['lowest'])+'% min/akun') if q.get('lowest') is not None else 'N/A'
        model_label=(model or '-') + (' [cfg]' if config_only else '')
        result[aid]={'id':aid,'task':task,'model':model_label,'status':status,
                     'start':hh_wib(start), 'last':hh_wib(end or ms_last_run(row)),
                     'duration':duration,'quota':quota_display,'session':key}
    return result


def load_config():
    p=Path.home()/'.openclaw/openclaw.json'
    try:
        data=json.loads(p.read_text())
        if not isinstance(data,dict):raise ValueError('config object invalid')
        return data
    except (OSError,ValueError):
        return {'agents':{'entries':{}},'models':{'providers':{}}}




def tiny(text, n):
    # No multiline cells on a small Termius screen.
    s=' '.join(clean(text).replace('\r',' ').replace('\n',' ').split())
    return s if len(s)<=n else s[:max(0,n-1)]+'…'


def smart_model(m, limit):
    value=str(m or '-').replace('9router/','').replace(' [cfg]','')
    parts=value.split('/',1)
    if len(parts)<2:return tiny(value,limit)
    provider,model=parts
    model=model.split('/')[-1]
    # Aliases are display-only. Original full model ID remains in session logs.
    model=model.replace('claude-sonnet-','Sonnet').replace('claude-haiku-','Haiku')
    model=model.replace('qwen3-coder-next','Qwen3Coder').replace('qwen2.5-coder-32b-instruct','Qwen2.5-32B')
    model=model.replace('gemini-','Gemini').replace('glm-','GLM')
    model=model.replace('-agentic','-A').replace('-thinking','-T')
    model=model.replace('4-6','4.6').replace('4.5','4.5').replace('3.8','3.8')
    model=model.replace('-flash','F')
    return tiny(provider+'/'+model, limit)


def st_label(status, gate=''):
    if status=='RUNNING':return '[bold green]KERJA[/]'
    if status=='BLOCKED':return '[bold red]BLOCK[/]'
    if status=='ERROR':return '[bold red]ERROR[/]'
    if status=='WAITING':return '[yellow]WAIT[/]'
    if status=='NEED APPROVAL':return '[yellow]APPROVAL[/]'
    if status=='STALE':return '[yellow]STALE[/]'
    if status=='DONE':return '[cyan]SELESAI[/]'
    if status=='IDLE':return '[cyan]IDLE[/]'
    return '[dim]—[/]'


def make_mobile(agents, quota, sessions_error, cron_run, cron_error, state,
                completed, masked, verified_count, interval, width):
    # A fixed-height mobile layout; the old matrix took >100 lines on Android.
    width=max(45,int(width))
    now=datetime.now(WIB).strftime('%H:%M:%S')
    cols=[]
    if width < 60:
        taskwidth=10; modelwidth=10
    elif width < 65:
        taskwidth=14; modelwidth=13
    elif width < 81:
        taskwidth=20; modelwidth=17
    else:
        taskwidth=33; modelwidth=26
    top=Text.from_markup('[bold cyan]IDSE  •  LIVE[/]   '+now+' WIB   •   '+str(verified_count)+' model')
    entry=cron_run if isinstance(cron_run,dict) else {}
    cstatus=(entry.get('completionStatus') or entry.get('status') or 'BELUM ADA RUN').upper()
    ct=hh_wib(entry.get('runAtMs'))[:5] if entry else '-'
    ccol='green' if cstatus in ('SUCCEEDED','OK','SUCCESS') else ('red' if cstatus in ('FAILED','ERROR','TIMED_OUT') else 'yellow')
    cron=Text.from_markup(f'Controller: [{ccol}]{tiny(cstatus,15)}[/] • terakhir {ct} WIB • refresh {interval}s')
    decision, reason=approval_signal(state,entry)
    dcol='yellow' if decision=='NEED APPROVAL' else ('red' if decision in ('BLOCKED','CONTROLLER ERROR') else 'cyan')
    decision_line=Text.from_markup(f'PROYEK: [{dcol}]{decision}[/] • {tiny(reason,max(22,width-25))}')
    t=Table(box=box.SIMPLE, show_header=True, show_edge=False,
            pad_edge=False, expand=False, padding=(0,1))
    t.add_column('AGENT',style='bold',no_wrap=True,width=6 if width<60 else 7)
    t.add_column('STATUS',width=8 if width<60 else 9,no_wrap=True)
    t.add_column('MULAI',width=5,no_wrap=True)
    t.add_column('MODEL',width=modelwidth,no_wrap=True,overflow='ellipsis')
    t.add_column('TUGAS',width=taskwidth,no_wrap=True,overflow='ellipsis')
    for aid,a in agents.items():
        gate=state.get('gates',{}).get(aid,'')
        label=ROLE.get(aid,aid)
        t.add_row(label,st_label(a['status'],gate),a['start'][:5] if a['start']!='-' else '-',
                  smart_model(a['model'],modelwidth),tiny(a['task'],taskwidth))
    # Router is a two-line summary instead of a seven-row quota table.
    qs=[]
    for provider in ('kr','ag','cf','gemini'):
        x=quota.get(provider,{})
        val=x.get('lowest')
        qs.append(provider.upper()+':' + (str(val)+'%min' if val is not None else 'N/A'))
    router_head=Text.from_markup('[bold]9ROUTER[/]  API key: [yellow]'+tiny(masked,32)+'[/]')
    quota_line=Text('Kuota upstream¹: '+'  '.join(qs),style='dim')
    # Progress report: only *explicitly* marked completed items, never session ended.
    hist=Table(box=box.SIMPLE,show_header=True,show_edge=False,pad_edge=False,
               padding=(0,1),expand=False)
    hist.add_column('AGENT',width=8,no_wrap=True)
    hist.add_column('TUGAS TERCATAT SELESAI²',width=max(16,min(width-14,64)),
                    overflow='ellipsis',no_wrap=True)
    done = list(completed)
    for a,desc,src in done[-3:]:
        nm=str(a).replace('idse-','').upper()[:8]
        hist.add_row(nm,tiny(desc,max(16,min(width-14,64))))
    if not done:
        hist.add_row('-','Belum ada bukti milestone selesai dari state/laporan')
    foot='¹ %min bukan total kuota. ² Milestone di laporan ≠ audit independen.'
    errors=[]
    if sessions_error:errors.append('Session: '+tiny(sessions_error,55))
    if cron_error:errors.append('Cron: '+tiny(cron_error,55))
    if cstatus in ('FAILED','ERROR','TIMED_OUT'):
        errors.append('Master/controller terakhir gagal; cek cron runs.')
    blocks=[top,cron,decision_line,Text('State diperbarui: '+state.get('updated','-'),style='dim'),
            t,Text('ROUTER / KUOTA',style='bold cyan'),router_head,quota_line,
            Text('RIWAYAT PEKERJAAN',style='bold cyan'),hist]
    history=state.get('history',[])
    if history:
        blocks.append(Text('EVENT TERBARU (STATE)',style='bold cyan'))
        for ts,ev,note in history[-2:]:
            blocks.append(Text(tiny(ev+' '+note, max(35,width-2)),style='dim'))
    if len(done)>3: blocks.append(Text(f'+{len(done)-3} item lain di laporan',style='dim'))
    if errors:blocks.append(Text(' | '.join(errors),style='red'))
    blocks.append(Text(foot,style='dim'))
    return Group(*blocks)


def main():
    parser=argparse.ArgumentParser(description='IDSE OpenClaw Mobile Rich Monitor v3 (read only)')
    parser.add_argument('--interval',type=int,default=20)
    parser.add_argument('--columns',type=int,default=5,help='Diterima demi kompatibilitas versi lama; mode HP tetap ringkas')
    parser.add_argument('--quota-login',action='store_true',help='Opsional: login dashboard 9Router untuk kuota')
    parser.add_argument('--once',action='store_true',help='Tampilkan satu snapshot dan keluar')
    parser.add_argument('--cron-id',default=DEFAULT_JOB)
    parser.add_argument('--workspace-root',default=str(Path.home()/'idse-ai-workspaces'))
    args=parser.parse_args()
    if args.interval<10:parser.error('--interval minimal 10 detik')
    console=Console()
    if os.geteuid()==0:
        console.print('[yellow]Jalankan sebagai reaagent, bukan root.[/]')
    reader=QuotaReader('http://127.0.0.1:20128')
    if args.quota_login:
        if not reader.login():console.print('[yellow]Kuota dashboard belum terbaca: '+clean(reader.error)+'[/]')
    root=Path(args.workspace_root)
    state_path=root/'idse-master/IDSE_AUTONOMOUS_STATE.json'
    pool_path=Path.home()/'.openclaw/idse-model-pool/verified_pool.json'
    last_cron={};last_cron_err=None;last_cron_poll=0
    def poll():
        nonlocal last_cron,last_cron_err,last_cron_poll
        if time.monotonic()-last_cron_poll>40 or not last_cron_poll:
            last_cron,last_cron_err=last_cron_run(args.cron_id)
            last_cron_poll=time.monotonic()
        config=load_config()
        rows,err=session_rows()
        sessions=latest_sessions(rows)
        keys=[(sessions.get(a,{}).get('key') or sessions.get(a,{}).get('sessionKey') or fallback_sessions(a)) for a in AGENTS]
        tails=get_tails(keys)
        reader.poll()
        quotas=reader.by_provider()
        state=parse_state(state_path)
        completed=read_completed(root,state)
        assignments=tasks_from_cron(last_cron.get('summary','') if last_cron else '')
        agents=build_agents(config,rows,tails,state,assignments,quotas)
        dispatch_time=norm_epoch(last_cron.get('runAtMs')) if last_cron else None
        if dispatch_time:
            for aid in assignments:
                a=agents.get(aid)
                if a and a['status'] in ('IDLE','UNKNOWN'):
                    key=a['session']; last_evt=tails.get(key,{}).get('end') or ms_last_run(sessions.get(aid,{}))
                    if not last_evt or last_evt+timedelta(seconds=5)<dispatch_time:
                        a['status']='WAITING'
        try:verified_count=len(json.loads(pool_path.read_text()).get('verified_refs',[]))
        except (OSError,ValueError):verified_count='?'
        return make_mobile(agents,quotas,err,last_cron,last_cron_err,state,completed,
                           read_router_key(config),verified_count,args.interval,console.size.width)
    if args.once:
        console.print('[dim]Membaca sesi OpenClaw...[/]')
        console.print(poll());return 0
    # Screen=False: tmux displays loading text immediately. Background fetch
    # keeps the UI responsive instead of blanking the screen for ~30 seconds.
    with concurrent.futures.ThreadPoolExecutor(max_workers=1) as executor:
        with Live(Text('IDSE MONITOR • memuat data OpenClaw...',style='cyan'),
                  console=console,refresh_per_second=2,screen=False,vertical_overflow='crop') as live:
            future=executor.submit(poll)
            last_done=0.0
            try:
                while True:
                    if future is not None and future.done():
                        try: live.update(future.result(),refresh=True)
                        except Exception as ex:
                            live.update(Text('Monitor gagal membaca data: '+type(ex).__name__+'; mencoba lagi...',style='red'),refresh=True)
                        last_done=time.monotonic()
                        future=None
                    if future is None and time.monotonic()-last_done>=args.interval:
                        future=executor.submit(poll)
                    time.sleep(.25)
            except KeyboardInterrupt:
                # Pending read-only jobs finish in their own short CLI timeout.
                live.stop()
                console.print('[dim]Monitor dihentikan. Agent/cron tetap berjalan.[/]')
    return 0

if __name__=='__main__':
    raise SystemExit(main())
